# Algorithm Timer

An easy-to-use algorithm timer.
